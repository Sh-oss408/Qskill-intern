export default function Home() {
  return (
    <div className="page">
      <h1>Welcome!</h1>
      <p>
        Welcome to my Front-End Development (React, Tailwind) Internship Project with Translator and Random String
        Generator.
      </p>
    </div>
  );
}

